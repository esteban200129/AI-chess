Contributing
============

Opening data is in `a.tsv`, `b.tsv`, `c.tsv`, `d.tsv`, and `e.tsv`.

Improvements, additions and fixes are welcome. If you have concrete
suggestions, please be bold and submit the proposed changes directly as pull
requests!

The changes will be live on lichess.org after the next update of
[scalachess](https://github.com/lichess-org/scalachess) (no fixed schedule)
and the
[opening explorer](https://github.com/lichess-org/lila-openingexplorer)
(daily).
